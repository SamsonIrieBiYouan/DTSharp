1)Installation de DTSharp
Lancer DTSharp 1.0.exe

2)Integration de DTSharp dans AutoCAD
Lorsque DTSharpIntegration s'ouvrira, selectionnez votre version d'autoCAD et cliquez sur "Integrer DTSharp Dans AutoCAD"

3)Puis Cliquez sur Ouvrir "DT Sharp"

4)La fenetre "Chargement du fichier - Problème de sécurité" apparait
-Cliquez sur "Toujours charger cette application"
-Ensuite cliquez sur "Charger"

5)Profitez du logiciel

