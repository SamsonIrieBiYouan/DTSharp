1)Etape1 : Retirer DTSharp dans AutoCAD

Ouvrez "DTSharp pour AutoCAD20XX"
Dans la barre de menu , cliquez sur "DTSharp"
puis cliquez sur "Retirer DTSharp Dans AutoCAD"

2)Etape2 : Retirer DTSharp sur Votre Bureau

Ouvrer le logiciel "DTSharp Integration"
cliquez sur "Retirer DTSharp dans AutoCAD"


3)Etape3 : Desinstaller DTSharp 1.0 dans windows

Desintaller normalement le logiciel avec l'outil windows "Ajouter et supprimer des programmes"
Desinstallez les deux logiciels : 
-DTSharp version 1.0
-DTSharp Integration


